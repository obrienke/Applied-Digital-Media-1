//retrieve from session storage and display on page.
document.getElementById("p1").textContent = sessionStorage.getItem("Username")+", you are now registered.";
